# clc-php-laravel-example
Computer Land - Code example for Web development with PHP Laravel Framework training course
