<?php $__env->startSection('content'); ?>

<div class="pt-3 pb-2 mb-3 border-bottom">
    <h2><?php echo e(__('Create New Post')); ?></h2>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <h4>Errors!</h4>
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e(route('posts.store')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Title')); ?></label>
        <div class="col-sm-10">
            <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control<?php echo e($errors->has('title')? ' is-invalid' : ''); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Content')); ?></label>
        <div class="col-sm-10">
            <textarea name="content" class="form-control<?php echo e($errors->has('content')? ' is-invalid' : ''); ?>"><?php echo e(old('content')); ?></textarea>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Image')); ?></label>
        <div class="col-sm-10">
            <input type="file" class="form-control<?php echo e($errors->has('image')? ' is-invalid' : ''); ?>" name="image">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Category')); ?></label>
        <div class="col-sm-10">
            <select class="form-control<?php echo e($errors->has('category_id')? ' is-invalid' : ''); ?>" name="category_id">
                <option disabled selected>Select category</option>
                <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"<?php echo e(old('category_id') == $category->id? ' selected' : ''); ?>><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Status')); ?></label>
        <div class="col-sm-10">

            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" value="draft"<?php echo e(old('status') == 'draft'? ' checked' : ''); ?>>
                <label class="form-check-label">Draft</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" value="published"<?php echo e(old('status') == 'published'? ' checked' : ''); ?>>
                <label class="form-check-label">Published</label>
            </div>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Tags')); ?></label>
        <div class="col-sm-10">
            <?php $__currentLoopData = App\Tag::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
                <input id="tag<?php echo e($tag->id); ?>" class="form-check-input" type="checkbox" name="tag_id[]" value="<?php echo e($tag->id); ?>" <?php echo e(in_array($tag->id, old('tag_id', []))? ' checked' : ''); ?>>
                <label for="tag<?php echo e($tag->id); ?>" class="form-check-label"><?php echo e($tag->name); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__errorArgs = ['tag_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-sm-10">
            <button class="btn btn-primary"><?php echo e(__('Save')); ?></button>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>