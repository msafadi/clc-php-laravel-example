<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
        <div class="container my-5">
            <h2 class="my-2"><?php echo e($post->title); ?></h2>
            <time><?php echo e($post->created_at); ?></time>
            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="d-block w-100">
            <p class="p-4"><?php echo e($post->content); ?></p>

            <section>
                <h4>Post Comments</h4>
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="my-2 border-1">
                    <h5><?php echo e($comment->user->name); ?></h5>
                    <time><?php echo e($comment->created_at); ?></time>
                    <p><?php echo e($comment->comment); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <section>
                <form method="post" action="<?php echo e(route('comments.store', [$post->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <textarea class="form-control my-5" name="comment"></textarea>
                    <button type="submit" class="btn btn-primary">Add Comment</button>
                </form>
            </section>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/post.blade.php ENDPATH**/ ?>