<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Website Title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>

    <header>

        <div class="topbar">
            <div class="container py-1 d-flex flex-wrap justify-content-between">
                <div>
                    <img src="/assets/images/logo.png" alt="Logo">
                </div>
                <nav class="nav">
                    <a class="nav-link" href="#"><i class="fas fa-rss"></i></a>
                    <a class="nav-link" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="nav-link" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="nav-link" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <span class="dropdown">
                        <a class="nav-link" href="#" data-toggle="dropdown"><i class="far fa-bell"></i> (<span id="noticount"><?php echo e(Auth::user()->unreadNotifications->count()); ?></span>)</a>
                        <div class="dropdown-menu" id="notilist">
                            <?php $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item<?php echo e($notification->read_at? '' : ' bg-light text-danger'); ?>" href="<?php echo e(route('notifications.read', [$notification->id])); ?>"><?php echo e($notification->data['message']); ?>

                                <time class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></time>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </span>
                </nav>
            </div>
        </div>
        <div class="container d-flex flex-wrap justify-content-between">
            <nav class="top-nav">
                <ul class="nav">
                    <li class="nav-item"><a href="" class="nav-link active"><?php echo e($title ?? 'Home'); ?></a></li>
                    <li class="nav-item"><a href="" class="nav-link">About us</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Service</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Pages</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Blog</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Contact us</a></li>
                </ul>
            </nav>
            <form action="" class="form-inline">
                <input type="search" placeholder="Search something" class="form-control">
            </form>
        </div>

    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <?php echo $__env->yieldContent('footer'); ?>
    </footer>
    <script>
        var userId = <?php echo e(Auth::id()); ?>;
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    
    
</body>

</html><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/layouts/layout.blade.php ENDPATH**/ ?>