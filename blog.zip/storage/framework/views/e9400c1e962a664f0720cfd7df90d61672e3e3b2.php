<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h2><?php echo e(__('Trashed Posts')); ?></h2>
    <a class="btn btn-outline-success btn-sm mb-2 mb-md-0" href="<?php echo e(route('posts.create')); ?>"><?php echo e(__('New')); ?></a>
</div>

<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <p><?php echo e(session('message')); ?></p>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger">
    <p><?php echo e(session('error')); ?></p>
</div>
<?php endif; ?>

<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>Deleted At</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->deleted_at); ?></td>
            <td>
                <form class="d-inline form-inline delete" action="<?php echo e(route('posts.restore', [$post->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit" class="btn btn-sm btn-link text-danger">Restore</button>
                </form>
                <form class="d-inline form-inline delete" action="<?php echo e(route('posts.forceDelete', [$post->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-link text-danger">Force Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('form.delete').on('submit', function(e) {
        if (!window.confirm('Are you sure?')) {
            e.preventDefault();
        }

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/admin/posts/trash.blade.php ENDPATH**/ ?>