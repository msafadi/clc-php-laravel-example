<?php echo e($slot); ?>

<?php /**PATH D:\www\clc-php-course-example\blog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>