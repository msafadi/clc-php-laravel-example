<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h2><?php echo app('translator')->get('admin.posts'); ?></h2>
    <a class="btn btn-outline-success btn-sm mb-2 mb-md-0" href="<?php echo e(route('posts.create')); ?>"><?php echo e(trans('admin.new')); ?></a>
</div>

<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <p><?php echo e(session('message')); ?></p>
</div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<div class="alert alert-danger">
    <p><?php echo e(session('error')); ?></p>
</div>
<?php endif; ?>

<table class="table">
    <thead>
        <tr>
            <th><?php echo e(__('Id')); ?></th>
            <th><?php echo e(__('Title')); ?></th>
            <th><?php echo e(__('Category')); ?></th>
            <th><?php echo e(__('Created At')); ?></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->category->name); ?></td>
            <td><?php echo e($post->created_at); ?></td>
            <td><a href="<?php echo e(route('posts.edit', [$post->id])); ?>"><?php echo e(__('Edit the post')); ?></a>
                <form class="d-inline form-inline delete" action="<?php echo e(route('posts.destroy', [$post->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-link text-danger"><?php echo e(__('Delete')); ?></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($posts->links()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('form.delete').on('submit', function(e) {
        if (!window.confirm('Are you sure?')) {
            e.preventDefault();
        }

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>