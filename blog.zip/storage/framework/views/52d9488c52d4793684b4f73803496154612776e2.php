<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Posts</h2>
    <table class="table my-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Status</th>
                <th>Category</th>
                <th>User</th>
                <th>Date</th>
                <th></th>
            </tr>
        </thead>
        <tbody id="posts">
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
$(document).ready(function() {
    $.getJSON('<?php echo e(route('api.posts.index')); ?>', function(res) {
        let table = $('#posts');
        for (i in res.data) {
            post = res.data[i];
            table.append('<tr>\
            <td>' + post.id + '</td>\
            <td>' + post.title + '</td>\
            <td>' + post.status + '</td>\
            <td>' + post.category.name + '</td>\
            <td>' + post.user.name + '</td>\
            <td>' + post.created_at + '</td>\
            <td><a href="#" data-action="delete" data-id="' + post.id + '">Delete</a></td>\
            </tr>');
        }
    });

    $('#posts').on('click', 'a[data-action="delete"]', function(e) {
        e.preventDefault();

        let url = '<?php echo e(route('api.posts.destroy', ['#'])); ?>';
        url = url.replace('#', $(this).data('id'));


        $.ajax(url, {
            method: "DELETE"
        }).done(function(res) {
            if (res.message == 'Deleted') {
                alert('Post deleted!');
                $('[data-id="' + res.data.id +'"]').parent().parent().remove();
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/api/posts/index.blade.php ENDPATH**/ ?>