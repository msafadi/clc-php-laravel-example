<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <p style="">Hello <?php echo e($name); ?>,</p>
    <p><?php echo e($mail_message); ?></p>
    <a href="<?php echo e($action_url); ?>"><?php echo e($action_text); ?></a>
    <p>Thank you!</p>
</body>
</html><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/mails/notification.blade.php ENDPATH**/ ?>