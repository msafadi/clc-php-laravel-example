<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Create Post</h2>

    <form id="postform" action="<?php echo e(route('api.posts.store')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
        <div class="form-group row">
            <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Title')); ?></label>
            <div class="col-sm-10">
                <input type="text" name="title" value="" class="form-control">
            </div>
        </div>
        <div class="form-group row">
            <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Content')); ?></label>
            <div class="col-sm-10">
                <textarea name="content" class="form-control"></textarea>
            </div>
        </div>
        <div class="form-group row">
            <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Image')); ?></label>
            <div class="col-sm-10">
                <input type="file" class="form-control" name="image">
            </div>
        </div>
        <div class="form-group row">
            <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Category')); ?></label>
            <div class="col-sm-10">
                <select class="form-control" name="category_id">
                    <option disabled selected>Select category</option>
                    <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Status')); ?></label>
            <div class="col-sm-10">

                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" value="draft">
                    <label class="form-check-label">Draft</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" value="published">
                    <label class="form-check-label">Published</label>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <label for="" class="col-sm-2 col-form-label"><?php echo e(__('Tags')); ?></label>
            <div class="col-sm-10">
                <?php $__currentLoopData = App\Tag::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-inline">
                    <input id="tag<?php echo e($tag->id); ?>" class="form-check-input" type="checkbox" name="tag_id[]" value="<?php echo e($tag->id); ?>">
                    <label for="tag<?php echo e($tag->id); ?>" class="form-check-label"><?php echo e($tag->name); ?></label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-10">
                <button class="btn btn-primary"><?php echo e(__('Save')); ?></button>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    $('#postform').on('submit', function(e) {
        e.preventDefault();
        //alert($(this).serialize());

        $.ajax($(this).attr('action'), {
            method: "POST",
            data: $(this).serialize()
        }).done(function(res) {
            if (res.id) {
                alert('Post created!');
                window.location = "/api/views/posts";
            }
        });
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/api/posts/form.blade.php ENDPATH**/ ?>