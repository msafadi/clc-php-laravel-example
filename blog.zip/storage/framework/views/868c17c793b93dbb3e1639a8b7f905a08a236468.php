<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h2><?php echo e(__('Categories')); ?></h2>
    <a class="btn btn-outline-success btn-sm mb-2 mb-md-0" href="<?php echo e(route('categories.create')); ?>"><?php echo e(__('New')); ?></a>
</div>

<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <p><?php echo e(session('message')); ?></p>
</div>
<?php endif; ?>

<table class="table">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Posts #</th>
            <th>Created At</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->posts->count()); ?></td>
            <td><?php echo e($category->created_at); ?></td>
            <td><a href="<?php echo e(route('categories.edit', [$category->id])); ?>">Edit</a>
            <form class="d-inline form-inline delete" action="<?php echo e(route('categories.destroy', [$category->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-sm btn-link text-danger">Delete</button>
            </form></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
$('form.delete').on('submit', function(e) {
    if (!window.confirm('Are you sure?')) {
        e.preventDefault();
    }

});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\clc-php-course-example\blog\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>