<?php

return [
    'edit' => ['تحرير'],
    'delete' => 'حذف',
    'new' => 'جديد',
    'posts' => 'المقالات',
    'post' => [
        'label' => 'المقال'
    ]
];