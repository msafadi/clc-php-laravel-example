<?php

return [
    'edit' => 'Edit',
    'delete' => 'Delete',
    'new' => 'New',
    'posts' => 'Posts',
];